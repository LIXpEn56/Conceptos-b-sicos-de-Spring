package com.example.messagefilter.aspect.aspect.service;


import org.springframework.stereotype.Service;

@Service
public class MessageService {
    public String processMessage(String message) {
        return message;
    }
}

