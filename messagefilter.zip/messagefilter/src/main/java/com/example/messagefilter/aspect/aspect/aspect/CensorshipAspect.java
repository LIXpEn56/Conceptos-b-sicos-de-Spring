package com.example.messagefilter.aspect.aspect.aspect;


import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Aspect
@Component
public class CensorshipAspect {

    private final List<String> forbiddenWords;

    public CensorshipAspect(List<String> forbiddenWords) {
        this.forbiddenWords = forbiddenWords;
    }

    @Around("execution(* com.example.service.MessageService.processMessage(..))")
    public Object censorMessage(ProceedingJoinPoint joinPoint) throws Throwable {
        String originalMessage = (String) joinPoint.getArgs()[0];

        int count = 0;
        String censoredMessage = originalMessage;

        for (String word : forbiddenWords) {
            if (censoredMessage.toLowerCase().contains(word.toLowerCase())) {
                count++;
                censoredMessage = censoredMessage.replaceAll("(?i)\\b" + word + "\\b", "!#?%@");
            }
        }

        if (count > 3) {
            return "[ADVERTENCIA] El mensaje contiene demasiadas palabras inapropiadas.";
        }

        return joinPoint.proceed(new Object[]{censoredMessage});
    }
}

