package com.example.messagefilter.aspect.aspect;



import com.example.messagefilter.aspect.aspect.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import jakarta.annotation.PostConstruct;
import java.util.Scanner;

@SpringBootApplication
public class Application {

    @Autowired
    private MessageService messageService;

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @PostConstruct
    public void startApp() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Escribe tu mensaje (Ctrl+C para salir):");

        while (true) {
            String input = scanner.nextLine();
            String result = messageService.processMessage(input);
            System.out.println(result);
        }
    }
}

