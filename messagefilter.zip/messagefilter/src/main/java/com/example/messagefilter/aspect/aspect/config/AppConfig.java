package com.example.messagefilter.aspect.aspect.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class AppConfig {
    @Bean
    public List<String> forbiddenWords() {
        return List.of("malo", "feo", "tonto", "grosero, estúpido"); // puedes agregar más
    }
}

